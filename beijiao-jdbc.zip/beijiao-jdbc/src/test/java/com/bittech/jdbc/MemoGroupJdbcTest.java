package com.bittech.jdbc;

import org.junit.Test;

/**
 * Author: secondriver
 * Created: 2018/6/25
 */
public class MemoGroupJdbcTest {
    
    @Test
    public void testInsertMemoGroup() {
        System.out.println("Insert MemoGroup");
    }
    
    
}
